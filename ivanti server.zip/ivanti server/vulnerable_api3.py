from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

# index.html 서빙
@app.route('/')
def serve_html():
    return send_from_directory('.', 'index3.html')

# 로고 요청 처리
@app.route('/favicon.ico')
def favicon():
    return '', 204  # 요청 없애기만 함

# 인증 우회 (실습용)
@app.route('/api/v1/unauthenticated-access', methods=['POST'])
def login_bypass():
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')

    # 실제 검증은 하지 않음
    if username and password:
        return jsonify({"status": "bypassed login"}), 200
    else:
        return jsonify({"error": "unauthorized"}), 401

# 명령어 삽입 실행
@app.route('/api/v1/exec_cmd', methods=['POST'])
def exec_cmd():
    data = request.get_json()
    cmd = data.get('cmd', '')

    try:
        result = os.popen(cmd).read()
        return jsonify({"result": result}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8443, ssl_context='adhoc')
