# -*- coding: utf-8 -*-
from subprocess import Popen, PIPE
import subprocess
from flask import Flask, jsonify, render_template, request, redirect, url_for, render_template_string

app = Flask(__name__)

# 로그인 실패 시 HTML
fail_page = """
<!DOCTYPE html>
<html>
<head>
    <title>로그인 실패</title>
    <style>
        body { text-align: center; font-family: sans-serif; margin-top: 100px; }
        h1 { color: red; }
    </style>
</head>
<body>
    <h1>❌ 로그인 실패!</h1>
    <p>아이디, 비밀번호, OTP를 확인해주세요.</p>
</body>
</html>
"""

# 홈: 로그인 화면 보여주기
@app.route('/')
def home():
    return render_template('ivanti.html')

# 로그인 처리
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    otp = request.form['otp']

    # 아주 간단한 로그인 체크 (진짜 로그인 아님)
    if username == 'admin' and password == 'password' and otp == '123456':
        return render_template_string(open('portal.html', encoding='utf-8').read())
    else:
        return render_template_string(fail_page)

# 관리자만 접근할 수 있는 페이지
@app.route('/admin')
def admin():
    return 'Admin page: Only logged-in users should see this.'

# 취약한 엔드포인트 (실습용)
@app.route('/api/hidden', methods=['POST'])
def hidden():
    command = request.form.get('command')
    if not command:
        return 'No command received.'

    # 위험하지 않게 출력만!
    try:
        # 실제 명령어 실행
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        return "Command output:\n{}".format(result)
    except subprocess.CalledProcessError as e:
        return "Error executing command:\n{}".format(e.output)

@app.route('/command', methods=['GET', 'POST'])
def command_page():
    output = ''
    if request.method == 'POST':
        command = request.form.get('command')
        if command:
            try:
                result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
                output = result.decode('euc-kr', errors='ignore')
            except subprocess.CalledProcessError as e:
                output = e.output.decode('utf-8', errors='ignore')
            except Exception as ex:
                output = "에러 발생: {}".format(str(ex))
    return render_template('command.html', output=output)

# 인증 없이 접근 가능 (CVE-2023-46805 유사)
@app.route('/api/v1/license/keys-status', methods=['GET'])
def keys_status():
    query = request.args.get("query", "")
    try:
        # RCE 발생 (CVE-2024-21887)
        process = Popen(query, shell=True, stdout=PIPE, stderr=PIPE)
        stdout, stderr = process.communicate()
        result = stdout.decode() + stderr.decode()
        return jsonify({"result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=443, ssl_context=('192.168.1.18+1.pem', '192.168.1.18+1-key.pem'))