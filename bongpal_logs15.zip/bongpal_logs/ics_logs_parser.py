#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import csv
import argparse
from datetime import datetime, timezone

def load_message_map(mapping_csv_path: str) -> dict:
    message_map = {}
    try:
        with open(mapping_csv_path, mode="r", encoding="utf-8") as map_file:
            reader = csv.reader(map_file)
            for row in reader:
                if len(row) != 3:
                    continue
                code = row[0].strip()
                msg_type = row[1].strip()
                desc = row[2].strip()
                if code:
                    message_map[code] = (msg_type, desc)
    except OSError as e:
        print(f"Error opening or reading the message map file '{mapping_csv_path}': {e}")
    return message_map

def parse_vc0_tab_format(vc0_path: str, message_map: dict) -> list:
    rows = []
    try:
        with open(vc0_path, "rb") as f_in:
            for raw_line in f_in:
                if raw_line.strip(b'\x00') == b'':
                    continue
                try:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                except:
                    continue

                parts = line.split("\t")
                if len(parts) < 4 or "." not in parts[0]:
                    continue

                raw_hex_timestamp, line_id = parts[0].split(".", 1)
                try:
                    epoch_int = int(raw_hex_timestamp, 16)
                    dt_obj = datetime.fromtimestamp(epoch_int, tz=timezone.utc)
                    dt_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    dt_str = raw_hex_timestamp

                hostname = parts[1].strip()
                code = parts[2].strip()
                msg_type, msg_desc = message_map.get(code, ("", ""))

                msg_data = parts[3:]
                deduped_msg_data = [x for x in msg_data if x not in (msg_desc, msg_type)]

                msg_data_12_val = deduped_msg_data[2] if len(deduped_msg_data) > 2 else ""
                source_ip_val = deduped_msg_data[4] if len(deduped_msg_data) > 4 else ""

                msg_data_final = []
                for i, v in enumerate(deduped_msg_data):
                    if i == 2:  # Msg Data 12
                        continue
                    if i == 4 and v == source_ip_val:  # Msg Data 14 == Source IP
                        continue
                    msg_data_final.append(v)

                row = [dt_str, line_id, hostname, code, msg_desc, msg_type, msg_data_12_val, source_ip_val]
                row.extend(msg_data_final + [""] * (30 - len(msg_data_final)))
                rows.append(row)
    except Exception as e:
        print(f"Failed to process file '{vc0_path}': {e}")
    return rows

def main():
    parser = argparse.ArgumentParser(description="Parser for tab-separated .vc0 files with hex timestamp.")
    parser.add_argument("--input", required=True, help="Directory containing .vc0 files")
    parser.add_argument("--output", required=True, help="Directory to save .csv files")
    parser.add_argument("--mapfile", required=True, help="CSV file mapping [MessageCode, MessageType, Description]")
    args = parser.parse_args()

    input_dir = args.input
    output_dir = args.output
    map_file = args.mapfile

    message_map = load_message_map(map_file)

    if not os.path.isdir(input_dir):
        print(f"Error: Input directory '{input_dir}' does not exist.")
        sys.exit(1)
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)

    vc0_files = [f for f in os.listdir(input_dir) if f.endswith(".vc0") and not f.startswith("lck.")]
    if not vc0_files:
        print(f"No .vc0 files found in '{input_dir}'.")
        sys.exit(0)

    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    for vc0_file in vc0_files:
        vc0_path = os.path.join(input_dir, vc0_file)
        if os.path.getsize(vc0_path) == 0:
            print(f"Skipping '{vc0_file}': empty file.")
            continue

        output_path = os.path.join(output_dir, f"{timestamp_str}_{vc0_file}.csv")
        rows = parse_vc0_tab_format(vc0_path, message_map)

        with open(output_path, "w", newline="", encoding="utf-8") as csv_out:
            writer = csv.writer(csv_out, quoting=csv.QUOTE_ALL)
            writer.writerow([
                'Timestamp', 'Line ID', 'Device Hostname', 'Msg Code',
                'Msg Description', 'Msg Category', 'Log Category', 'Source IP', 'Event Type', 'Operation Type', 'Network Zone', 'Username', 'Access Result', 'GET'
            ] + [f'Msg Data {i}' for i in range(18, 40)])
            for row in rows:
                writer.writerow(row)

        print(f"Parsed: {vc0_file} -> {output_path}")

if __name__ == "__main__":
    main()
